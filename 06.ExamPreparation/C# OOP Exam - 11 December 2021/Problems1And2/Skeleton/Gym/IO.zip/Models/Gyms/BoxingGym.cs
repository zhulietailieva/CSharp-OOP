﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Gym.Models.Gyms
{
    public class BoxingGym : Gym
    {
        private const int CAPACITY = 15;
        public BoxingGym(string name) : base(name, CAPACITY) { }

        public override void Exercise()
        {
            if (this.Athletes.Count == 0) return;
            foreach (var athlete in this.Athletes)
            {
                if (athlete.GetType().Name == "Boxer")
                    athlete.Exercise();

            }
        }
    }
}
